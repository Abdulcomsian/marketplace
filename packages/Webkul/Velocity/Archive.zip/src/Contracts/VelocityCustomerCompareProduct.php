<?php

namespace Webkul\Velocity\Contracts;

interface VelocityCustomerCompareProduct
{
}