<?php

namespace Webkul\Velocity\Contracts;

interface Category
{
}