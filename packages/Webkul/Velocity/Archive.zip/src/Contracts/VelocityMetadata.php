<?php

namespace Webkul\Velocity\Contracts;

interface VelocityMetadata
{
}