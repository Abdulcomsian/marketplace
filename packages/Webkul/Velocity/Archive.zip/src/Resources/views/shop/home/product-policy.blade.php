<div class="container-fluid product-policy-container no-padding">
    <div class="row">
        {!! $velocityMetaData->product_policy !!}
    </div>
</div>
