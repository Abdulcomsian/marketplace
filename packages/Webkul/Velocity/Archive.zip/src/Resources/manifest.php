<?php

return [
    'name'    => 'Webkul Bagisto Velocity',
    'version' => '0.0.1',
];
