<?php

namespace Webkul\Velocity\Models;

use Konekt\Concord\Proxies\ModelProxy;

class ContentTranslationProxy extends ModelProxy
{

}